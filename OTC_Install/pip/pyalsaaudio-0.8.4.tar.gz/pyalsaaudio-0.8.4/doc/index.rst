alsaaudio documentation
=======================

.. toctree::
   :maxdepth: 2

   pyalsaaudio
   terminology
   libalsaaudio


Github pages
=================

* `Project page <https://github.com/larsimmisch/pyalsaaudio/>`_
* `Download from pypi <https://pypi.python.org/pypi/pyalsaaudio>`_
* `Bug tracker <https://github.com/larsimmisch/pyalsaaudio/issues>`_


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

